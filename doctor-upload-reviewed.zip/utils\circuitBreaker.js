"use strict";
/**
 * Circuit Breaker Pattern Implementation
 * Prevents cascading failures and provides fallback behavior
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.s3CircuitBreaker = exports.CircuitBreaker = void 0;
class CircuitBreaker {
    constructor(options = {}) {
        this.options = {
            failureThreshold: 5,
            resetTimeout: 60000, // 1 minute
            monitoringPeriod: 10000, // 10 seconds
            ...options
        };
        this.state = {
            failures: 0,
            lastFailureTime: 0,
            state: 'CLOSED'
        };
    }
    /**
     * Executes a function with circuit breaker protection
     */
    async execute(fn, fallback) {
        const currentState = this.state.state;
        if (currentState === 'OPEN') {
            if (this.shouldAttemptReset()) {
                this.state.state = 'HALF_OPEN';
            }
            else {
                if (fallback) {
                    console.warn('Circuit breaker OPEN, using fallback');
                    return fallback();
                }
                throw new Error('Circuit breaker is OPEN');
            }
        }
        try {
            const result = await fn();
            this.onSuccess();
            return result;
        }
        catch (error) {
            this.onFailure();
            if (fallback && this.state.state === 'OPEN') {
                console.warn('Circuit breaker OPEN after failure, using fallback');
                return fallback();
            }
            throw error;
        }
    }
    onSuccess() {
        this.state.failures = 0;
        this.state.state = 'CLOSED';
    }
    onFailure() {
        this.state.failures++;
        this.state.lastFailureTime = Date.now();
        if (this.state.failures >= this.options.failureThreshold) {
            this.state.state = 'OPEN';
            console.warn(`Circuit breaker OPEN after ${this.state.failures} failures`);
        }
    }
    shouldAttemptReset() {
        return this.state.state === 'OPEN' &&
            Date.now() - this.state.lastFailureTime >= this.options.resetTimeout;
    }
    /**
     * Gets current circuit breaker state
     */
    getState() {
        return this.state.state;
    }
    /**
     * Gets failure count
     */
    getFailureCount() {
        return this.state.failures;
    }
    /**
     * Manually resets the circuit breaker
     */
    reset() {
        this.state = {
            failures: 0,
            lastFailureTime: 0,
            state: 'CLOSED'
        };
    }
}
exports.CircuitBreaker = CircuitBreaker;
// Global circuit breaker instances
exports.s3CircuitBreaker = new CircuitBreaker({
    failureThreshold: 3,
    resetTimeout: 30000, // 30 seconds
    monitoringPeriod: 10000
});
