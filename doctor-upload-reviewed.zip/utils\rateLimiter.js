"use strict";
/**
 * Rate Limiting Utilities
 * Simple in-memory rate limiting for API protection
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkRateLimit = checkRateLimit;
exports.getClientIdentifier = getClientIdentifier;
exports.cleanupExpiredEntries = cleanupExpiredEntries;
// In-memory store (for production, use Redis or DynamoDB)
const rateLimitStore = new Map();
/**
 * Checks if a request should be rate limited
 * @param identifier - Unique identifier (IP address, API key, etc.)
 * @param limit - Maximum requests allowed
 * @param windowMs - Time window in milliseconds
 * @returns Object with allowed status and remaining requests
 */
function checkRateLimit(identifier, limit = 100, windowMs = 60000 // 1 minute
) {
    const now = Date.now();
    const entry = rateLimitStore.get(identifier);
    if (!entry || now > entry.resetTime) {
        // New window or expired entry
        const newEntry = {
            count: 1,
            resetTime: now + windowMs
        };
        rateLimitStore.set(identifier, newEntry);
        return {
            allowed: true,
            remaining: limit - 1,
            resetTime: newEntry.resetTime
        };
    }
    // Existing window
    if (entry.count >= limit) {
        return {
            allowed: false,
            remaining: 0,
            resetTime: entry.resetTime
        };
    }
    // Increment counter
    entry.count++;
    rateLimitStore.set(identifier, entry);
    return {
        allowed: true,
        remaining: limit - entry.count,
        resetTime: entry.resetTime
    };
}
/**
 * Extracts client identifier from request
 */
function getClientIdentifier(event) {
    // Try to get client IP from various headers
    const ip = event.headers?.['x-forwarded-for'] ||
        event.headers?.['x-real-ip'] ||
        event.requestContext?.identity?.sourceIp ||
        'unknown';
    // If multiple IPs, take the first one
    return ip.split(',')[0].trim();
}
/**
 * Cleanup expired entries (call periodically)
 */
function cleanupExpiredEntries() {
    const now = Date.now();
    for (const [key, entry] of rateLimitStore.entries()) {
        if (now > entry.resetTime) {
            rateLimitStore.delete(key);
        }
    }
}
