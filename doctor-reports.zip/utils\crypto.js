"use strict";
/**
 * Cryptographic Utilities
 * Production-grade cryptographically secure random string generation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateSecureRandomString = generateSecureRandomString;
exports.generateRecordId = generateRecordId;
exports.generatePatientId = generatePatientId;
exports.generateTimestampId = generateTimestampId;
const crypto_1 = require("crypto");
/**
 * Generates a cryptographically secure random string
 */
function generateSecureRandomString(length) {
    const bytes = (0, crypto_1.randomBytes)(Math.ceil(length / 2));
    return bytes.toString('hex').slice(0, length);
}
/**
 * Generates a unique record ID
 */
function generateRecordId() {
    return generateSecureRandomString(32);
}
/**
 * Generates a unique patient ID
 */
function generatePatientId() {
    const prefix = 'P';
    const randomPart = generateSecureRandomString(8);
    return `${prefix}${randomPart}`;
}
/**
 * Generates a timestamp-based unique identifier
 */
function generateTimestampId() {
    const timestamp = Date.now().toString(36);
    const randomPart = generateSecureRandomString(8);
    return `${timestamp}_${randomPart}`;
}
