"use strict";
/**
 * API Handler: GET /api/doctor/reports
 * Lists PDF ECG reports for doctors with presigned URLs.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const s3Service_1 = require("./services/s3Service");
const response_1 = require("./utils/response");
exports.handler = (0, response_1.withErrorHandler)(async (event) => {
    // Support both REST API (v1) and HTTP API (v2) event formats
    const httpMethod = event.httpMethod || event.requestContext?.http?.method || event.requestContext?.httpMethod;
    const routeKey = event.routeKey; // HTTP API v2 format: "GET /api/doctor/reports"
    // Check method - support both formats
    const method = httpMethod || (routeKey ? routeKey.split(' ')[0] : null);
    if (method !== "GET") {
        if (method === "OPTIONS") {
            return (0, response_1.createSuccessResponse)({ message: "CORS preflight" }, 200);
        }
        return (0, response_1.createSuccessResponse)({ message: "Method not allowed" }, 405);
    }
    const objects = await (0, s3Service_1.listECGObjects)();
    // Only include PDF files from the main ECG prefix
    const pdfObjects = objects.filter((obj) => obj.Key &&
        obj.Key.endsWith(".pdf") &&
        !obj.Key.startsWith("reports/reviewed/"));
    const reports = [];
    for (const obj of pdfObjects) {
        const key = obj.Key;
        const filename = key.split("/").pop() || key;
        try {
            // Verify the file actually exists before generating presigned URL
            // This prevents NoSuchKey errors when accessing stale list entries
            const exists = await (0, s3Service_1.checkObjectExists)(key);
            if (!exists) {
                console.warn(`Skipping ${key} - file does not exist in S3`);
                continue;
            }
            // Generate presigned URL directly from the S3 key
            const presignedUrl = await (0, s3Service_1.generatePresignedUrlFromKey)(key);
            reports.push({
                key,
                fileName: filename,
                url: presignedUrl,
                uploadedAt: obj.LastModified, // Primary field
                lastModified: obj.LastModified, // Backward compatibility
            });
        }
        catch (error) {
            console.error("Failed to generate doctor report URL for", key, error);
            // Skip this report if URL generation fails
        }
    }
    // Newest first
    reports.sort((a, b) => {
        const ta = (a.uploadedAt || a.lastModified) ? new Date(a.uploadedAt || a.lastModified || '').getTime() : 0;
        const tb = (b.uploadedAt || b.lastModified) ? new Date(b.uploadedAt || b.lastModified || '').getTime() : 0;
        return tb - ta;
    });
    return (0, response_1.createSuccessResponse)({
        success: true,
        reports,
    }, 200);
});
